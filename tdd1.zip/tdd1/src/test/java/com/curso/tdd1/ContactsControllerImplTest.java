package com.curso.tdd1;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.test.context.support.WithUserDetails;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.WebApplicationContext;

import com.curso.tdd1.config.WebSecConfig;
import com.curso.tdd1.controllerImpl.ContactsControllerImpl;

import lombok.extern.slf4j.Slf4j;

@WebMvcTest(ContactsControllerImpl.class)
@Import(WebSecConfig.class)
@Slf4j
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@DisplayName("<= Contacts Controller Impl Test =>")
class ContactsControllerImplTest {
	
	@Autowired
	private MockMvc mockMvc;
	
	@Autowired
	private WebApplicationContext context;
	
	@Mock
	private UserDetailsService userDetailsService;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
		userDetailsService = context.getBean(UserDetailsService.class);
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	@DisplayName("> Contacts Test As User logged")
	@Order(100)
	@WithUserDetails("user")
	void testContactsAsUserLogged() {
		//fail("Not yet implemented");
		try {
			this.mockMvc
				.perform(get("/contacts"))
				.andDo(print())
				.andExpect(view().name("/contacts"))
				.andExpect(status().isOk())
				.andExpect(model().attributeExists("username"))
				.andExpect(model().attribute("username", equalTo("user")))
				.andExpect(model().attributeExists("authoritiesString"))
				.andExpect(model().attribute("authoritiesString", equalTo("[ROLE_USER]")))
				.andExpect(content().string(containsString("Contactos")))
				.andExpect(content().string(containsString("Fusce dapibus, tellus ac cursus commodo")));
		} catch (Exception e) {
			log.info("EXCEPTION: " + e.getMessage());
			//e.printStackTrace();
		}
	}

	@Test
	@DisplayName("> Contacts Test As admin logged")
	@Order(200)
	@WithUserDetails("admin")
	void testContactsAsAdminLogged() {
		//fail("Not yet implemented");
		try {
			this.mockMvc
				.perform(get("/contacts"))
				.andDo(print())
				.andExpect(view().name("/contacts"))
				.andExpect(status().isOk())
				.andExpect(model().attributeExists("username"))
				.andExpect(model().attribute("username", equalTo("admin")))
				.andExpect(model().attributeExists("authoritiesString"))
				.andExpect(model().attribute("authoritiesString", containsString("ROLE_ADMIN")))
				.andExpect(content().string(containsString("Contactos")))
				.andExpect(content().string(containsString("Fusce dapibus, tellus ac cursus commodo")));
		} catch (Exception e) {
			log.info("EXCEPTION: " + e.getMessage());
			//e.printStackTrace();
		}
	}

}
