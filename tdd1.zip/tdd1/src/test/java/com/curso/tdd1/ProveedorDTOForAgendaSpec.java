package com.curso.tdd1;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer;

import com.curso.tdd1.data.dto.ProveedorDTOForAgenda;
import com.curso.tdd1.data.model.Proveedor;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@DisplayName("<= ProveedorDTOForAgenda Specification =>")
public class ProveedorDTOForAgendaSpec {

	private ProveedorDTOForAgendaSpec(TestInfo testInfo) {
		log.info("TRAZA paso por el constructor " + testInfo.getDisplayName());
	}
	
	@Test
	@Order(700)
	@DisplayName("> Grouping Assertions")
	public void groupingAssertion() {
		ProveedorDTOForAgenda proveedorDTOForAgenda = 
				new ProveedorDTOForAgenda();
		proveedorDTOForAgenda.add(new Proveedor("PEPE"));
		proveedorDTOForAgenda.add(new Proveedor("ANA"));		
		proveedorDTOForAgenda.add(new Proveedor("JUAN"));
		String proveedorListString = proveedorDTOForAgenda.toString();
		log.info("proveedorListString= " + proveedorListString);
		/*
		assertEquals(3, proveedorDTOForAgenda.getProveedorList().size(), 
				() -> "should have size = 3 but has " 
						+ proveedorDTOForAgenda.getProveedorList().size());
		assertTrue(proveedorListString.contains("PEPE"), () -> "PEPE is missing");
		assertTrue(proveedorListString.contains("LUISA"), () -> "LUISA is missing");
		assertTrue(proveedorListString.contains("JUAN"), () -> "JUAN is missing");
		*/
		//
		assertAll(
			() -> assertEquals(3, proveedorDTOForAgenda.getProveedorList().size(), 
						() -> "should have size = 3 but has " 
								+ proveedorDTOForAgenda.getProveedorList().size()),
			() -> assertTrue(proveedorListString.contains("PEPE"), () -> "PEPE is missing"),
			() -> assertTrue(proveedorListString.contains("ANA"), () -> "ANA is missing"),
			() -> assertTrue(proveedorListString.contains("JUAN"), () -> "JUAN is missing")
		);
	}

	@Test
	@Order(25)
	@DisplayName("This test should make error")
	public void thisTestShouldMakeError() {
		String string = null;
		//assertNotNull(string, () -> "string should be null");
		assertTrue(string.contains("CURSO"), () -> "string should contains CURSO");
	}
	
	@Test
	@Order(50)
	@DisplayName("This test should fail")
	public void thisTestShouldFail() {
		fail(() -> "This test should fail");
	}
	
	@Test
	@Order(600)
	@DisplayName("> Two Proveedor objects are equals")
	public void twoProveedorAreEquals(TestInfo testInfo) {
		Proveedor expected = new Proveedor();
		expected.setNombre("JUAN");
		Proveedor actual = new Proveedor();
		actual.setNombre("JUAN");
		expected = actual;
		assertSame(expected, actual, () -> "should be same");
		assertEquals(expected, actual, () -> "should be equals");
	}
	
	@Test
	@Order(500)
	@DisplayName("> Two String are equals")
	public void twoStringsAreEquals(TestInfo testInfo) {
		String expected = "PEPE";
		String actual = "PEPE";
		assertEquals(expected, actual, () -> "should be equals");
		assertSame(expected, actual, () -> "should be same");
	}
	
	@Test
	@Order(400)
	@DisplayName("> Two Integers are equals")
	public void twoIntegersAreEquals(TestInfo testInfo) {
		Integer expected = 3;
		Integer actual = 3;
		assertSame(expected, actual, () -> "should be same");
		assertEquals(expected, actual, () -> "should be equals");
	}
	
	@Test
	@Order(100)
	@DisplayName("> proveedorList Is Empty When No Proveedor has Added")
	public void proveedorListIsEmptyWhenNoProveedorAdded() {
		ProveedorDTOForAgenda proveedorDTOForAgenda = new ProveedorDTOForAgenda();
		List<Proveedor> proveedorList = proveedorDTOForAgenda.getProveedorList();
		assertTrue(proveedorList.isEmpty(), "proveedorList should be empty");
		assertFalse(!proveedorList.isEmpty(), "proveedorList should be empty");		
	}
	
	@Test
	@Order(200)
	@DisplayName("> proveedorList Is Not Empty When Almost One Proveedor has Added")
	public void proveedorListIsNotEmptyWhenAlmostOneProveedorAdded() {
		ProveedorDTOForAgenda proveedorDTOForAgenda = new ProveedorDTOForAgenda();
		List<Proveedor> proveedorList = proveedorDTOForAgenda.getProveedorList();
		proveedorList.add(new Proveedor());
		assertTrue(!proveedorList.isEmpty(), () -> "proveedorList should NOT be empty");		
	}
	
	@Test
	@Order(300)
	@DisplayName("> should Check For Even Numbers")
	void shouldCheckForEvenNumbers() {
		int number = new Random(10).nextInt();
		assertTrue(() -> number%2 == 0, 
				() -> (number + " is not an even number."));
	
		/*
		BiFunction<Integer, Integer, Boolean> divisible = (x, y) -> x % y == 0;
			Function<Integer, Boolean> multipleOf2 = (x) -> divisible.apply(x, 2);
			assertTrue(() -> multipleOf2.apply(number), () -> " 2 is not factor of " +
			number);
		*/
		
		List<Integer> numbers = Arrays.asList(1, 1, 1, 1, 2);
		assertTrue(() -> numbers.stream().distinct()
			.anyMatch(ProveedorDTOForAgendaSpec::isEven),
				() -> "Did not find an even number in the list");
	}
	
	static boolean isEven(int number) {
		return number % 2 == 0;
	}
	
	
}

