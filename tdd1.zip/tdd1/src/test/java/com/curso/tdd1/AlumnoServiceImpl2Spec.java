package com.curso.tdd1;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import javax.validation.ConstraintViolationException;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.SqlGroup;
import org.junit.jupiter.api.MethodOrderer;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import com.curso.tdd1.data.model.Alumno;
import com.curso.tdd1.data.model.Capitulo;
import com.curso.tdd1.data.model.Estudiar;
import com.curso.tdd1.data.repository.IAlumnoRepository;
import com.curso.tdd1.data.repository.ICapituloRepository;
import com.curso.tdd1.data.repository.IEstudiarRepository;
import com.curso.tdd1.serviceImpl.AlumnoServiceImpl2;

import lombok.Getter;
import lombok.extern.slf4j.Slf4j;

//@SpringBootTest(classes = Tdd101Application.class)
@ExtendWith(MockitoExtension.class)
@Slf4j
@Getter
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@DisplayName("<= AlumnoServiceImpl v2 Specification =>")
public class AlumnoServiceImpl2Spec {
	
	// Finals (constants):
	private final Double MINIMUM_NOTA = 5.0;
	private final Long PERCENT = 100L;
	
	// Mock attributes:
	private List<Alumno> alumnoList = null;
	private Alumno alumno1 = null;
	private Alumno alumno2 = null;
	private Alumno alumno3 = null;
	private Alumno alumno4 = null;
	private Alumno alumno5 = null;
	//
	private List<Capitulo> capituloList = null;
	private Capitulo capitulo1 = null;
	private Capitulo capitulo2 = null;
	private Capitulo capitulo3 = null;
	private Capitulo capitulo4 = null;
	//
	private List<Estudiar> estudiarList = null;
	private Estudiar estudiar1 = null;
	private Estudiar estudiar2 = null;
	private Estudiar estudiar3 = null;
	private Estudiar estudiar4 = null;
	private Estudiar estudiar5 = null;
	private Estudiar estudiar6 = null;
	private Estudiar estudiar7 = null;
	private Estudiar estudiar8 = null;

	@Mock
	private IAlumnoRepository alumnoRepository;

	@Mock
	private ICapituloRepository capituloRepository;
	
	@Mock
	private IEstudiarRepository estudiarRepository;
	
	@InjectMocks
	private AlumnoServiceImpl2 alumnoService;
	
	private AlumnoServiceImpl2Spec(TestInfo testInfo) {
		log.info("TRAZA paso por el constructor " + testInfo.getDisplayName());
	}
	
	@BeforeAll
	@DisplayName("> before All")
	public static void beforeAll(TestInfo testInfo) {
		log.info("beforeAll: " + testInfo.getDisplayName());
	}
	
	@BeforeEach
	@DisplayName("> before Each")
	public void beforeEach(TestInfo testInfo) {
		log.info("beforeEach: " + testInfo.getDisplayName());	
		MockitoAnnotations.openMocks(this);
	}

	@AfterEach
	@DisplayName("> after Each")
	public void afterEach(TestInfo testInfo) {
		log.info("afterEach: " + testInfo.getDisplayName());		
	}

	@Test
	@Order(800)
	@DisplayName("> right progress calculation of student with Empty Capitulo shows Exception")
	public void rightProgressCalculationOfStudentWithEmptyCapituloShowsException() {
		//fail(() -> "should be fail");
		//
		// Mocks
		initialMocksLoading();
		//
		// Test
		assertEquals(50L,
			calculateProgressAlumno(this.alumno3, (long)capituloList.size()),
			() -> "should be " + (long)capituloList.size()
			);	
		assertEquals(Double.POSITIVE_INFINITY,
			calculateProgressAlumno(this.alumno3, 0L),
			() -> "should be " + Double.POSITIVE_INFINITY
			);	
	}
	
	private Double calculateProgressAlumno(Alumno alumno, Long countCapitulo) {
		Long finishedCapitulo = alumno
				.getEstudiarSet()
				.stream()
				.filter(x -> (x.getFFin() != null) 
						&& (x.getNota() != null)
						&& (x.getNota() >= MINIMUM_NOTA))
				.count();
		Double progress = null;
		//
		try {
			progress = (double)(finishedCapitulo * PERCENT) / (double)countCapitulo;
		}
		catch (ArithmeticException e) {
			log.info("Table Capitulo is empty!!!");
			progress = Double.POSITIVE_INFINITY;
		}		
		return progress;
	}

	/*
	private long calculateProgressAlumno(long finishedCapitulo, long countCapitulo)
		throws ArithmeticException {
			return (finishedCapitulo * 100) / countCapitulo;
	}
	*/
	
	
	@Test
	@Order(700)
	@DisplayName("> right progress calculation of student with NO records in Estudiar")
	public void rightProgressCalculationOfStudentWithNoRecordsInEstudiar() {
		//fail(() -> "should be fail");
		//
		// Mocks
		initialMocksLoading();
		when(capituloRepository.count())
			.thenReturn((long)capituloList.size());
		when(alumnoRepository.findOptionalByNif("4D"))
			.thenReturn(Optional.of(alumno4));
		//
		// Test
		long countCapitulo = capituloRepository.count();
		long finishedCapitulo = alumnoRepository.findOptionalByNif("4D")
			.get()
			.getEstudiarSet()
			.stream()
			.filter(x -> (x.getFFin() != null) 
					&& (x.getNota() != null) 
					&& (x.getNota() >= 5.0))
			.count();
		assertEquals(4, countCapitulo, () -> "count should be equals: 4");
		assertEquals(0, (finishedCapitulo * 100) / countCapitulo,
				() -> "should be 0%");	
	}
	
	@Test
	@Order(600)
	@DisplayName("> right progress calculation of student with records in Estudiar")
	public void rightProgressCalculationOfStudentWithRecordsInEstudiar() {
		//fail(() -> "should be fail");
		//
		// Mocks
		initialMocksLoading();
		when(capituloRepository.count())
			.thenReturn((long)capituloList.size());
		when(alumnoRepository.findOptionalByNif("3C"))
			.thenReturn(Optional.of(alumno3));
		//
		// Test
		long countCapitulo = capituloRepository.count();
		long finishedCapitulo = alumnoRepository.findOptionalByNif("3C")
			.get()
			.getEstudiarSet()
			.stream()
			.filter(x -> (x.getFFin() != null) 
					&& (x.getNota() != null) 
					&& (x.getNota() >= 5.0))
			.count();
		assertEquals(4, countCapitulo, () -> "count should be equals: 4");
		assertEquals(50, (finishedCapitulo * 100) / countCapitulo,
				() -> "should be 50%");	
	}

	@Test
	@Order(500)
	@DisplayName("> adding Capitulo with existing or null or out-of-range Orden shows exceptions")
	public void addingCapituloWithExistingOrNullOrOutofrangeOrdenShowsExceptions() {
		//fail(() -> "should be fail");
		//
		// Mocks
		initialMocksLoading();
		when(capituloRepository.save(new Capitulo(null, 2, "CAPITULO 2", null)))
			.thenThrow(DataIntegrityViolationException.class);
		when(capituloRepository.save(new Capitulo(null, null, "CAPITULO 2", null)))
			.thenThrow(DataIntegrityViolationException.class);		
		when(capituloRepository.save(new Capitulo(null, -1, "CAPITULO 2", null)))
			.thenThrow(ConstraintViolationException.class);
		when(capituloRepository.save(new Capitulo(null, 100, "CAPITULO 2", null)))
			.thenThrow(ConstraintViolationException.class);
		//
		// Test
		assertAll(
			() -> assertThrows(
				DataIntegrityViolationException.class,
				() -> capituloRepository.save(new Capitulo(null, 2, "CAPITULO 2", null)),
				() -> "Microtest 1 - should shows DataIntegrityViolationException"
			),
			() -> assertThrows(
					DataIntegrityViolationException.class,
					() -> capituloRepository.save(new Capitulo(null, null, "CAPITULO 2", null)),
					() -> "Microtest 2 - should shows DataIntegrityViolationException"
			),
			() -> assertThrows(
					ConstraintViolationException.class,
					() -> capituloRepository.save(new Capitulo(null, -1, "CAPITULO 2", null)),
					() -> "Microtest 3 - should shows ConstraintViolationException"
			),		
			() -> assertThrows(
					ConstraintViolationException.class,
					() -> capituloRepository.save(new Capitulo(null, 100, "CAPITULO 2", null)),
					() -> "Microtest 4 - should shows ConstraintViolationException"
			)			
		);
		verify(this.capituloRepository, times(5)).save(any(Capitulo.class));
	}
	
	@Test
	@Order(400)
	@DisplayName("> adding Alumno with existing or null nif and null nombre shows exceptions")
	public void addingAlumnoWithExistingOrNullNifAndNullNombreShowsExceptions() {
		//fail(() -> "should be fail");
		//
		// Mocks
		initialMocksLoading();
		when(alumnoRepository.save(new Alumno(null, "4D", "PATO DONALD", null)))
			.thenThrow(DataIntegrityViolationException.class);
		when(alumnoRepository.save(new Alumno(null, null, "MICKEY MOUSE", null)))
			.thenThrow(DataIntegrityViolationException.class);
		when(alumnoRepository.save(new Alumno(null, "8J", null, null)))
			.thenThrow(DataIntegrityViolationException.class);	
		//
		// Test
		assertAll(
			() -> assertThrows(
				DataIntegrityViolationException.class,
				() -> alumnoRepository.save(new Alumno(null, "4D", "PATO DONALD", null)),
				() -> "Microtest 1 - should shows DataIntegrityViolationException"
			),
			() -> assertThrows(
					DataIntegrityViolationException.class,
					() -> alumnoRepository.save(new Alumno(null, null, "MICKEY MOUSE", null)),
					() -> "Microtest 2 - should shows DataIntegrityViolationException"
			),
			() -> assertThrows(
					DataIntegrityViolationException.class,
					() -> alumnoRepository.save(new Alumno(null, "8J", null, null)),
					() -> "Microtest 3 - should shows DataIntegrityViolationException"
			)		
		);
	}

	@Test
	@Order(300)
	@DisplayName("> adding Alumno with existing nif shows exception")
	public void addingAlumnoWithExistingNifShowsException() {
		//fail(() -> "should be fail");
		//
		// Mocks
		initialMocksLoading();
		when(alumnoRepository.save(new Alumno(null, "4D", "PATO DONALD", null)))
			.thenThrow(DataIntegrityViolationException.class);
		//
		// Test
		assertThrows(
			DataIntegrityViolationException.class,
			() -> alumnoRepository.save(new Alumno(null, "4D", "PATO DONALD", null)),
			() -> "should shows DataIntegrityViolationException"
		);	
		verify(this.alumnoRepository, times(1)).save(any(Alumno.class));
	}
	
	@Test
	@Order(200)
	@DisplayName("> deleting Alumno delete Estudiar in Cascade")
	public void deletingAlumnoDeleteEstudiarInCascade() {		
		//fail(() -> "should be fail");
		//
		// Mocks
		this.initialMocksLoading();
		Alumno expected = alumno3;
		Set<Estudiar> estudiarSet = expected.getEstudiarSet();		
		when(alumnoService.deleteById(expected.getId()))		
			.thenReturn(alumnoList.remove(alumno3));
		when(alumnoService.existsById(expected.getId()))		
			.thenReturn(alumnoList.contains(alumno3));
		estudiarList.removeAll(estudiarSet);	
		when(estudiarRepository.countByAlumnoId(expected.getId()))
			.thenReturn((int) estudiarList.stream()
					.filter(x -> x.getAlumno().getId() == expected.getId())
					.count()
					);		
		//
		// Test
		assertFalse(alumnoService.existsById(expected.getId()), 
				() -> "should not exists alumno with id= " + expected.getId());
		assertEquals(0, estudiarRepository.countByAlumnoId(expected.getId()),
			() -> "should be count = 0 but was= " + estudiarRepository.countByAlumnoId(expected.getId()));
	}
		
	@Test
	@Order(100)
	@DisplayName("> find existing Alumno by Nif in mocked list")
	public void findExistingAlumnoByNifInMockedList() {		
		//fail(() -> "should be fail");
		//
		// Mocks
		this.initialMocksLoading();
		when(alumnoRepository.findOptionalByNif("5E")).thenReturn(Optional.of(alumno5));
		//
		// Test
		Alumno expected = alumno5; //new Alumno(5L,"5E","ALUMNO 5",new HashSet<Estudiar>());
		Alumno actual = alumnoRepository.findOptionalByNif("5E").get();
		assertEquals(expected, actual, 
				() -> "alumno should be equals: " + actual);	
		verify(this.alumnoRepository, times(1)).findOptionalByNif("5E");
	}
	
	private void initialMocksLoading() {
		this.alumnoList = new ArrayList<>();
		this.alumno1 = new Alumno(1L,"1A","ALUMNO 1",null);
		this.alumno2 = new Alumno(2L,"2B","ALUMNO 2",null);
		this.alumno3 = new Alumno(3L,"3C","ALUMNO 3",null);
		this.alumno4 = new Alumno(4L,"4D","ALUMNO 4",null);
		this.alumno5 = new Alumno(5L,"5E","ALUMNO 5",null);
		alumnoList.add(alumno1);
		alumnoList.add(alumno2);
		alumnoList.add(alumno3);
		alumnoList.add(alumno4);
		alumnoList.add(alumno5);
		//
		this.capituloList = new ArrayList<>();
		this.capitulo1 = new Capitulo(1L,1,"CAPITULO 1",null);
		this.capitulo2 = new Capitulo(2L,2,"CAPITULO 2",null);
		this.capitulo3 = new Capitulo(3L,3,"CAPITULO 3",null);
		this.capitulo4 = new Capitulo(4L,4,"CAPITULO 4",null);
		capituloList.add(capitulo1);
		capituloList.add(capitulo2);
		capituloList.add(capitulo3);
		capituloList.add(capitulo4);
		//
		this.estudiarList = new ArrayList<>();
		this.estudiar1 = new Estudiar(1L,LocalDate.parse("2023-03-29"),LocalDate.parse("2023-03-31"),6.5,alumno1,capitulo1);
		this.estudiar2 = new Estudiar(2L,LocalDate.parse("2023-03-31"),LocalDate.parse("2023-04-30"),5.5,alumno1,capitulo2);
		this.estudiar3 = new Estudiar(3L,LocalDate.parse("2023-04-30"),null,null,alumno1,capitulo3);
		this.estudiar4 = new Estudiar(4L,LocalDate.parse("2023-03-29"),null,null,alumno2,capitulo1);
		this.estudiar5 = new Estudiar(5L,LocalDate.parse("2023-03-27"),LocalDate.parse("2023-04-28"),4.5,alumno3,capitulo1);
		this.estudiar6 = new Estudiar(6L,LocalDate.parse("2023-03-29"),LocalDate.parse("2023-04-30"),7.5,alumno3,capitulo1);
		this.estudiar7 = new Estudiar(7L,LocalDate.parse("2023-04-30"),LocalDate.parse("2023-05-05"),10.0,alumno3,capitulo2);
		this.estudiar8 = new Estudiar(8L,LocalDate.parse("2023-05-15"),null,null,alumno3,capitulo3);
		estudiarList.add(estudiar1);
		estudiarList.add(estudiar2);
		estudiarList.add(estudiar3);
		estudiarList.add(estudiar4);
		estudiarList.add(estudiar5);
		estudiarList.add(estudiar6);
		estudiarList.add(estudiar7);
		estudiarList.add(estudiar8);
		//
		this.alumno1.setEstudiarSet(new HashSet<Estudiar>(Set.of(estudiar1, estudiar2, estudiar3)));
		this.alumno2.setEstudiarSet(new HashSet<Estudiar>(Set.of(estudiar4)));
		this.alumno3.setEstudiarSet(new HashSet<Estudiar>(Set.of(estudiar5, estudiar6, estudiar7, estudiar8)));
		this.alumno4.setEstudiarSet(new HashSet<Estudiar>());
		//
		this.capitulo1.setEstudiarSet(new HashSet<Estudiar>(Set.of(estudiar1, estudiar4, estudiar5, estudiar6)));
		this.capitulo2.setEstudiarSet(new HashSet<Estudiar>(Set.of(estudiar2, estudiar7)));
		this.capitulo3.setEstudiarSet(new HashSet<Estudiar>(Set.of(estudiar3, estudiar8)));
		this.capitulo4.setEstudiarSet(new HashSet<Estudiar>());
		//
	}
	
}

