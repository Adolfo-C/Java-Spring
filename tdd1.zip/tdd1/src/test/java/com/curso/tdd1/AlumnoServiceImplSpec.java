package com.curso.tdd1;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.util.HashSet;
import java.util.Set;

import javax.validation.ConstraintViolationException;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.jdbc.SqlGroup;
import org.junit.jupiter.api.MethodOrderer;

import com.curso.tdd1.Tdd1Application;
import com.curso.tdd1.data.model.Alumno;
import com.curso.tdd1.data.model.Capitulo;
import com.curso.tdd1.data.model.Estudiar;
import com.curso.tdd1.data.repository.IAlumnoRepository;
import com.curso.tdd1.data.repository.ICapituloRepository;
import com.curso.tdd1.data.repository.IEstudiarRepository;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest(classes = Tdd1Application.class)
@Slf4j
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@DisplayName("<= AlumnoRepository Specification =>")
public class AlumnoServiceImplSpec {
	
	@Autowired
	private IAlumnoRepository alumnoRepository;

	@Autowired
	private ICapituloRepository capituloRepository;
	
	@Autowired
	private IEstudiarRepository estudiarRepository;
	
	private AlumnoServiceImplSpec(TestInfo testInfo) {
		log.info("TRAZA paso por el constructor " + testInfo.getDisplayName());
	}
	
	@BeforeAll
	@DisplayName("> before All")
	public static void beforeAll(TestInfo testInfo) {
		log.info("beforeAll: " + testInfo.getDisplayName());
	}
	
	@BeforeEach
	@DisplayName("> before Each")
	public void beforeEach(TestInfo testInfo) {
		log.info("beforeEach: " + testInfo.getDisplayName());		
	}

	@AfterEach
	@DisplayName("> after Each")
	public void afterEach(TestInfo testInfo) {
		log.info("afterEach: " + testInfo.getDisplayName());		
	}

	@Test
	@Order(800)
	@DisplayName("> right progress calculation of student with Empty Capitulo shows Exception")
	public void rightProgressCalculationOfStudentWithEmptyCapituloShowsException() {
		//fail(() -> "should be fail");
		long countCapitulo = 0L;
		long finishedCapitulo = 0L;
		assertThrows(
			ArithmeticException.class,
			() -> calculateProgressAlumno(finishedCapitulo, countCapitulo),
			() -> "should throws ArithmeticExcepcion"
			);	
	}
	
	private long calculateProgressAlumno(long finishedCapitulo, long countCapitulo)
		throws ArithmeticException {
			return (finishedCapitulo * 100) / countCapitulo;
	}
	
	
	@Test
	@Order(700)
	@DisplayName("> right progress calculation of student with NO records in Estudiar")
	public void rightProgressCalculationOfStudentWithNoRecordsInEstudiar() {
		//fail(() -> "should be fail");
		long countCapitulo = capituloRepository.count();
		long finishedCapitulo = alumnoRepository.findOptionalByNif("4D")
			.get()
			.getEstudiarSet()
			.stream()
			.filter(x -> (x.getFFin() != null) 
					&& (x.getNota() != null) 
					&& (x.getNota() >= 5.0))
			.count();
		assertEquals(4, countCapitulo, () -> "count should be equals: 4");
		assertEquals(0, (finishedCapitulo * 100) / countCapitulo,
				() -> "should be 0%");	
	}
	
	@Test
	@Order(600)
	@DisplayName("> right progress calculation of student with records in Estudiar")
	public void rightProgressCalculationOfStudentWithRecordsInEstudiar() {
		//fail(() -> "should be fail");
		long countCapitulo = capituloRepository.count();
		long finishedCapitulo = alumnoRepository.findOptionalByNif("3C")
			.get()
			.getEstudiarSet()
			.stream()
			.filter(x -> (x.getFFin() != null) 
					&& (x.getNota() != null) 
					&& (x.getNota() >= 5.0))
			.count();
		assertEquals(4, countCapitulo, () -> "count should be equals: 4");
		assertEquals(25, (finishedCapitulo * 100) / countCapitulo,
				() -> "should be 25%");	
	}

	@Test
	@Order(500)
	@DisplayName("> adding Capitulo with existing or null or out-of-range Orden shows exceptions")
	public void addingCapituloWithExistingOrNullOrOutofrangeOrdenShowsExceptions() {
		//fail(() -> "should be fail");
		assertAll(
			() -> assertThrows(
				DataIntegrityViolationException.class,
				() -> capituloRepository.save(new Capitulo(null, 2, "CAPITULO 2", null)),
				() -> "Microtest 1 - should shows DataIntegrityViolationException"
			),
			() -> assertThrows(
					DataIntegrityViolationException.class,
					() -> capituloRepository.save(new Capitulo(null, null, "CAPITULO 2", null)),
					() -> "Microtest 2 - should shows DataIntegrityViolationException"
			),
			() -> assertThrows(
					ConstraintViolationException.class,
					() -> capituloRepository.save(new Capitulo(null, -1, "CAPITULO 2", null)),
					() -> "Microtest 3 - should shows ConstraintViolationException"
			),		
			() -> assertThrows(
					ConstraintViolationException.class,
					() -> capituloRepository.save(new Capitulo(null, 100, "CAPITULO 2", null)),
					() -> "Microtest 4 - should shows ConstraintViolationException"
			)			
		);
	}
	
	@Test
	@Order(400)
	@DisplayName("> adding Alumno with existing or null nif and null nombre shows exceptions")
	public void addingAlumnoWithExistingOrNullNifAndNullNombreShowsExceptions() {
		//fail(() -> "should be fail");
		assertAll(
			() -> assertThrows(
				DataIntegrityViolationException.class,
				() -> alumnoRepository.save(new Alumno(null, "4D", "PATO DONALD", null)),
				() -> "Microtest 1 - should shows DataIntegrityViolationException"
			),
			() -> assertThrows(
					DataIntegrityViolationException.class,
					() -> alumnoRepository.save(new Alumno(null, null, "MICKEY MOUSE", null)),
					() -> "Microtest 2 - should shows DataIntegrityViolationException"
			),
			() -> assertThrows(
					DataIntegrityViolationException.class,
					() -> alumnoRepository.save(new Alumno(null, "8J", null, null)),
					() -> "Microtest 3 - should shows DataIntegrityViolationException"
			)		
		);
	}

	@Test
	@Order(300)
	@DisplayName("> adding Alumno with existing nif shows exception")
	public void addingAlumnoWithExistingNifShowsException() {
		//fail(() -> "should be fail");
		assertThrows(
			DataIntegrityViolationException.class,
			() -> alumnoRepository.save(new Alumno(null, "4D", "PATO DONALD", null)),
			() -> "should shows DataIntegrityViolationException"
		);		
	}
	
	@Test
	@SqlGroup({
	    @Sql(scripts = "classpath:sql/alumnoDataForBeforeEachTest.sql", executionPhase = Sql.ExecutionPhase.BEFORE_TEST_METHOD),
	    @Sql(scripts = "classpath:sql/alumnoDataForAfterEachTest.sql", executionPhase = Sql.ExecutionPhase.AFTER_TEST_METHOD)
	})
	@Order(200)
	@DisplayName("> deleting Alumno delete Estudiar in Cascade")
	public void deletingAlumnoDeleteEstudiarInCascade() {		
		//fail(() -> "should be fail");
		log.info("findAll: " + alumnoRepository.findAll());
		//assertTrue(true, "should be true");
		Alumno expected = alumnoRepository.findOptionalByNif("5E").get();
		Set<Estudiar> estudiarSet = expected.getEstudiarSet();
		alumnoRepository.deleteById(expected.getId());
		assertAll(
			() -> assertFalse(alumnoRepository.existsById(expected.getId()), 
				() -> "should not exists alumno with id= " + expected.getId()),
			() -> assertEquals(0, estudiarRepository.countByAlumnoId(expected.getId()),
				() -> "should be count = 0 but was= " + estudiarRepository.countByAlumnoId(expected.getId()))
		);
	}
		
	@Test
	@SqlGroup({
	    @Sql(scripts = "classpath:sql/alumnoDataForBeforeEachTest.sql", executionPhase = Sql.ExecutionPhase.BEFORE_TEST_METHOD),
	    @Sql(scripts = "classpath:sql/alumnoDataForAfterEachTest.sql", executionPhase = Sql.ExecutionPhase.AFTER_TEST_METHOD)
	})
	@Order(100)
	@DisplayName("> find existing Alumno by Nif in H2 table")
	public void findExistingAlumnoByNifInH2() {		
		//fail(() -> "should be fail");
		Alumno expected = new Alumno(5L,"5E","ALUMNO 5",new HashSet<Estudiar>());
		log.info("findAll: " + alumnoRepository.findAll());
		Alumno actual = alumnoRepository.findOptionalByNif("5E").get();
		//Alumno expected = new Alumno(4L,"4D","ALUMNO 4",new HashSet<Estudiar>());
		//Alumno actual = alumnoRepository.findOptionalByNif("4D").get();
		log.info("alumno expected= " + expected);
		log.info("alumno actual= " + actual);
		assertEquals(expected, actual, 
				() -> "alumno should be equals: " + actual);		
	}
	
}

