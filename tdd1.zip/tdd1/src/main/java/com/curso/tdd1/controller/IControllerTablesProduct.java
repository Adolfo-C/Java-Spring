package com.curso.tdd1.controller;

import java.security.Principal;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;

import com.curso.tdd1.data.model.Producto;

@Controller
public interface IControllerTablesProduct {
	
	public String productoList(
			Principal principal,
			Model model, 
			HttpServletRequest request);

	public String productoAdd(
			Principal principal, 
			Model model, 
			HttpServletRequest request);

	public String productoAdd(
			@Valid Producto producto,
			BindingResult bindingResult,
			Principal principal, 
			Model model, 
			HttpServletRequest request);
	
	public void dataToMaster(
			Principal principal, 
			Model model, 
			HttpServletRequest request);

	public String productoView(
			Long id, 
			Principal principal, 
			Model model, 
			HttpServletRequest request);

	public String productoUpdate(
			Long id, 
			Principal principal, 
			Model model, 
			HttpServletRequest request);

	public String productoUpdate(
			@Valid Producto producto,
			BindingResult bindingResult,
			Principal principal, 
			Model model, 
			HttpServletRequest request);
	
	public String productoDelete(
			Long id, 
			Principal principal, 
			Model model, 
			HttpServletRequest request);

	public String productoDelete(
			@Valid Producto producto,
			BindingResult bindingResult,
			Principal principal, 
			Model model, 
			HttpServletRequest request);
}
