package com.curso.tdd1.controllerImpl;

import java.security.Principal;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.curso.tdd1.controller.IControllerTablesProveedor;
import com.curso.tdd1.data.model.Proveedor;
import com.curso.tdd1.service.IProveedorService;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class TablesProveedorControllerImpl implements IControllerTablesProveedor {
    
    @Autowired
    private IProveedorService proveedorService;

    @Autowired
    private UserDetailsService userDetailsService;
    
	@Override
	@PostMapping(value = {"/proveedor/delete"})
	public String proveedorDelete(
			Proveedor proveedor,
			Principal principal, 
			Model model, 
			HttpServletRequest request) {
		log.info("TRAZA: método proveedorDelete-POST: " + proveedor);		
		// Borramos el proveedor:
		log.info("Eliminado el proveedor: " + proveedorService.deleteById(proveedor.getId()));
		// Inyectamos el usuario en la página
		model.addAttribute("username", principal.getName());
		// Inyectar la lista de roles
		model.addAttribute("authoritySet", 
			userDetailsService
			.loadUserByUsername(principal.getName())
			.getAuthorities()
			.stream()
			.map(x -> x.toString())
			.collect(Collectors.toSet())
			);
		//
		return "redirect:/proveedor" ;
	}
	
	@Override
	@GetMapping(value = {"/proveedor/delete/{id}"})
	public String proveedorDelete(
			@PathVariable("id") Long id,
			Principal principal, 
			Model model, 
			HttpServletRequest request) {
		log.info("TRAZA: método proveedorDelete-GET");
		// Inyectamos el proveedor:
		model.addAttribute("proveedor", proveedorService.findById(id).get());
		// Inyectamos el usuario en la página
		model.addAttribute("username", principal.getName());
		// Inyectar la lista de roles
		model.addAttribute("authoritySet", 
			userDetailsService
			.loadUserByUsername(principal.getName())
			.getAuthorities()
			.stream()
			.map(x -> x.toString())
			.collect(Collectors.toSet())
			);
		//
		return "/dialectLayouts/proveedor/proveedorDeleteCentral" ;
	}

	@Override
	@GetMapping(value = {"/proveedor"})
	public String proveedorList(Principal principal, Model model, HttpServletRequest request) {
		log.info("TRAZA: método proveedorList");
		// Primero ver si accedemos a todos los registros de la tabla:
		model.addAttribute("proveedorList", proveedorService.findAll());
		// Inyectamos el usuario en la página
		model.addAttribute("username", principal.getName());
		// Inyectar la lista de roles
		model.addAttribute("authoritySet", 
			userDetailsService
			.loadUserByUsername(principal.getName())
			.getAuthorities()
			.stream()
			.map(x -> x.toString())
			.collect(Collectors.toSet())
			);
		//
		return "/dialectLayouts/proveedor/proveedorListCentral" ;
	}

	@Override
	public void dataToMaster(Principal principal, Model model, HttpServletRequest request) {
		// Inyectamos el usuario en la página
		model.addAttribute("username", principal.getName());
		// Inyectar la lista de roles
		model.addAttribute("authoritySet", 
			userDetailsService
			.loadUserByUsername(principal.getName())
			.getAuthorities()
			.stream()
			.map(x -> x.toString())
			.collect(Collectors.toSet())
			);
		//		
	}
	
}


