package com.curso.tdd1.data.dto;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.format.annotation.DateTimeFormat;

import com.curso.tdd1.data.model.Cliente;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ComprarDTOForMultipleAdd implements Serializable {

	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private static final long serialVersionUID = 1L;
	
    @DateTimeFormat(pattern = "yyyy-MM-dd") // Formato ISO
	private LocalDate fecha; //LocalTime, LocalDateTime
	
    @ToString.Exclude
    private Cliente cliente;

    @ToString.Exclude
    Map<String, Integer> comprarMultipleMap = new LinkedHashMap<String, Integer>();

    /*
    CONTENIDO DE UN DTO CUALQUIERA:
    serialVersionUID = 1L
    fecha = 2023-05-10
    cliente = Cliente (id=1, nombre="PEPE", ...)
    comprarMultipleMap =
    	TORNILLO, 0
    	TUERCA, 0
    	GRAPA, 0
    	MASILLA, 0
    	
    A LA VUELTA DE LA VISTA RECUPERAREMOS:
    serialVersionUID = 1L
    fecha = 2023-05-10
    cliente = Cliente (id=1, nombre="PEPE", ...)
    comprarMultipleMap =
    	TORNILLO, 0
    	TUERCA, 4
    	GRAPA, 7
    	MASILLA, 0
    	
    A LA TABLA DE COMPRAR AÑADIREMOS XXX REGISTROS:
    	1, FK_PRODUCTO_ID("TUERCA"), FK_CLIENTE_ID(1), 2023-05-10, 4
    	2, FK_PRODUCTO_ID("GRAPA"), FK_CLIENTE_ID(1), 2023-05-10, 7
     */
    
}
