package com.curso.tdd1.controllerImpl;

import java.security.Principal;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.curso.tdd1.controller.IControllerTablesCustomer;
import com.curso.tdd1.data.model.Cliente;
import com.curso.tdd1.service.IClienteService;

import lombok.extern.slf4j.Slf4j;

@Controller
@RequestMapping("/customer")
@Slf4j
public class TablesCustomerControllerImpl implements IControllerTablesCustomer {
    
    @Autowired
    private IClienteService clienteService;
    
    @Autowired
    private UserDetailsService userDetailsService;
    
	@Override
	@GetMapping(value = {"/view/{id}"})
	public String clienteView(
			@PathVariable("id") Long id,
			Principal principal, 
			Model model, 
			HttpServletRequest request) {
		log.info("TRAZA: método clienteView");
		//
		model.addAttribute("cliente", clienteService.findById(id).get());
		this.dataToMaster(principal, model, request);
		return "/dialectLayouts/cliente/clienteViewCentral";
	}
	
	@Override
	@GetMapping(value = {"/add"})
	public String clienteAdd(Principal principal, Model model, HttpServletRequest request) {
		log.info("TRAZA: método clienteAdd");
		//
		model.addAttribute("cliente", clienteService.newCliente());
		this.dataToMaster(principal, model, request);
		return "/dialectLayouts/cliente/clienteAddCentral";
	}
    
	@Override
	@GetMapping(value = {"/page"})
	public String clienteList(Principal principal, Model model, HttpServletRequest request) {
		log.info("TRAZA: método clienteList");
		// Primero ver si accedemos a todos los registros de la tabla Cliente:
		model.addAttribute("clienteList", clienteService.findAll());
		//
		this.dataToMaster(principal, model, request);
		//return "/clienteList"; // Llama directamente a clienteList.html
		return "/dialectLayouts/cliente/clienteListCentral";
	}

	@Override
	public void dataToMaster(Principal principal, Model model, HttpServletRequest request) {
		// Inyectamos el usuario en la página
		model.addAttribute("username", principal.getName());
		// Inyectar la lista de roles
		model.addAttribute("authoritySet", 
			userDetailsService
			.loadUserByUsername(principal.getName())
			.getAuthorities()
			.stream()
			.map(x -> x.toString())
			.collect(Collectors.toSet())
			);
		//		
	}

	@Override
	@PostMapping(value = {"/add"})
	public String clienteAdd(
			@Valid Cliente cliente, 
			BindingResult bindingResult, 
			Principal principal, 
			Model model,
			HttpServletRequest request) {
		String returned = "";
		log.info("TRAZA: método clienteAdd-POST");
		if (bindingResult.hasErrors()) {
			log.info("HAY ERRORES DE VALIDACIÓN: " +  bindingResult.getAllErrors());
			this.dataToMaster(principal, model, request);
			returned = "/dialectLayouts/cliente/clienteAddCentral";
		}
		else {
			if (clienteService.existsByDni(cliente.getDni())) {
				log.info("DNI repetido: " + cliente.getDni());
				model.addAttribute("message", "DNI ya existente!");
				this.dataToMaster(principal, model, request);
				returned = "/dialectLayouts/cliente/clienteAddCentral";				
			}
			else {
				//cliente = clienteService.save(cliente);
				//log.info("Añadido cliente:" + cliente);
				log.info("Añadido cliente: " + clienteService.save(cliente));
				returned = "redirect:/customer/page";
			}
		}
		return returned;
	}

}