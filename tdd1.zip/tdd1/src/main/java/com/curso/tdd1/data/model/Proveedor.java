package com.curso.tdd1.data.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.AccessLevel;

@Entity
@Table(name = "proveedor")
@XmlRootElement
@Getter
@Setter
@NoArgsConstructor
@ToString
public class Proveedor implements Serializable {

	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private static final long serialVersionUID = 1L;
	
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)    
	@Basic(optional = false)
    @Column(name = "ID", unique=true, nullable=false) 
	private Long id;
	
    @Column(name = "NIF")
	private String nif;
	
    @Column(name = "NOMBRE")
	private String nombre;
	
    @Column(name = "DIRECCION")
	private String direccion;

    // orphanRemoval: es muy importante ponerlo a true para que al borrar un Proveedor 
    // se borren automáticamente todos sus Productos asociados.
    //
    // CascadeType.ALL: entity relationships defined with ALL, will ensure that all 
    // persistence events such as persist, refresh, merge and remove that occur on the parent, 
    // will be passed to the child.
    //
    // mappedBy="...": usado para relacionar el Entity del lado One con el Entity del lado Many
    // (sólo cuando es bidireccional).
    //
    @ToString.Exclude // Necesario para evitar bucle infinito
    @OneToMany(mappedBy = "proveedor", cascade = CascadeType.ALL, 
    		fetch = FetchType.LAZY, orphanRemoval = true)
    private List<Producto> productoList = new ArrayList<Producto>();

    //Constructor con nombre
    public Proveedor(String nombre) {
    	this.nombre = nombre;
    }    
    
}
