package com.curso.tdd1.serviceImpl;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.curso.tdd1.data.model.Cliente;
import com.curso.tdd1.data.repository.IClienteRepository;
import com.curso.tdd1.service.IClienteService;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Service
@Getter
@Setter
@NoArgsConstructor
@ToString
public class ClienteServiceImpl implements IClienteService {

	@Autowired
	private IClienteRepository clienteRepository;
	
	@Override
	public List<Cliente> findAll() {
		//List<Cliente> clienteList = clienteRepository.findAll();		
		return Collections.unmodifiableList(clienteRepository.findAll());
	}

	@Override
	public Optional<Cliente> findById(Long id) {
		return clienteRepository.findById(id);
	}

	@Override
	public Cliente save(Cliente cliente) {
		return clienteRepository.save(cliente);
	}

	@Override
	public Boolean deleteById(Long id) {
		clienteRepository.deleteById(id);		
		return !this.existsById(id);
	}
	
	@Override
	public Boolean existsById(Long id) {
		return clienteRepository.existsById(id);
	}

	@Override
	public Cliente newCliente() {
		return new Cliente();
	}

	@Override
	public Boolean existsByDni(String dni) {
		return clienteRepository.existsByDni(dni);
	}


}
