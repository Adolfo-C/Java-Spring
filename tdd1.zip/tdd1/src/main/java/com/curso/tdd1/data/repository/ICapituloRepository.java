package com.curso.tdd1.data.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.curso.tdd1.data.model.Capitulo;
import java.util.Optional;

import javax.transaction.Transactional;

@Repository
@Transactional
public interface ICapituloRepository extends JpaRepository<Capitulo, Long> {
		
}
