package com.curso.tdd1.controller;

import java.security.Principal;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

@Controller
public interface IControllerAbout {
	
	public String about(
			Principal principal,
			Model model, 
			HttpServletRequest request);

	public void dataToMaster(
			Principal principal, 
			Model model, 
			HttpServletRequest request);
	
}
