package com.curso.tdd1.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.curso.tdd1.data.model.Cliente;

@Service
public interface IClienteService {

	public List<Cliente> findAll(); 
	
	public Optional<Cliente> findById(Long id);
	
	public Cliente save(Cliente cliente);
	
	public Boolean deleteById(Long id);
	
	public Boolean existsById(Long id); 
	
	public Cliente newCliente();
	
	public Boolean existsByDni(String dni);

}
