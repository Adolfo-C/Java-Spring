package com.curso.tdd1.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.curso.tdd1.data.model.Cliente;
import com.curso.tdd1.data.model.Comprar;

@Service
public interface IComprarService {

	public List<Comprar> findAll(); 
	
	public Optional<Comprar> findOptionalById(Long id);

	public Comprar save(Comprar comprar);
	
	public Boolean deleteById(Long id);
	
	public Boolean existsById(Long id); 
	
	public Comprar newComprar();

	public Comprar newComprar(LocalDate fecha, Cliente cliente);
	
}
