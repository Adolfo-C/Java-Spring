package com.curso.tdd1.data.model;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.AccessLevel;

@Entity
@Table(name = "comprar")
@XmlRootElement
@Getter
@Setter
@NoArgsConstructor
@ToString
public class Comprar implements Serializable {

	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private static final long serialVersionUID = 1L;
	
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)    
	@Basic(optional = false)
    @Column(name = "ID", unique=true, nullable=false) 
	private Long id;
	
    @Column(name = "UNIDADES")
    @Min(value = 0, message = "Unidades no puede ser negativo")
    @Max(value = 999999, message = "Unidades no puede ser mayor de 999999")
	private Integer unidades;
	
    @Column(name = "FECHA")
    @DateTimeFormat(pattern = "yyyy-MM-dd") // Formato ISO
	private LocalDate fecha; //LocalTime, LocalDateTime
	
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name="FK_CLIENTE_ID")
    @ToString.Exclude
    private Cliente cliente;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name="FK_PRODUCTO_ID")
    @ToString.Exclude
    private Producto producto;
}
