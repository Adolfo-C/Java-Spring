package com.curso.tdd1.serviceImpl;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.curso.tdd1.data.model.Comprar;
import com.curso.tdd1.data.dto.ComprarDTOForMultipleAdd;
import com.curso.tdd1.data.repository.IComprarRepository;
import com.curso.tdd1.service.IComprarDTOForMultipleAddService;
import com.curso.tdd1.service.IComprarService;
import com.curso.tdd1.service.IProductoService;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

@Service
@Getter
@Setter
@NoArgsConstructor
@ToString
@Slf4j
public class ComprarDTOForMultipleAddServiceImpl implements IComprarDTOForMultipleAddService {

	@Autowired
	private IComprarRepository comprarRepository;

	@Autowired
	private IProductoService productoService;

	@Autowired
	private IComprarService comprarService;
	
	@Override
	public List<Comprar> saveMultiple(ComprarDTOForMultipleAdd comprarDTO) {
		log.info("TRAZA: saveMultiple de ComprarDTOForMultipleAddServiceImpl");
		List<Comprar> comprarMultipleList = new ArrayList<Comprar>();
		Integer value = 0;
		for (String key : comprarDTO.getComprarMultipleMap().keySet()) {
			value = comprarDTO.getComprarMultipleMap().get(key);
			if (value != 0) {
				Comprar nextComprar = comprarService.newComprar(comprarDTO.getFecha(), comprarDTO.getCliente());
				nextComprar.setProducto(productoService.findOptionalByDescripcion(key).get());
				nextComprar.setUnidades(value);
				nextComprar = comprarService.save(nextComprar);
				comprarMultipleList.add(nextComprar);
			}
		}
		return comprarMultipleList;
	}

	@Override
	public ComprarDTOForMultipleAdd newDTO() {
		ComprarDTOForMultipleAdd comprarDTO = new ComprarDTOForMultipleAdd();
		comprarDTO.setFecha(LocalDate.now());
		return comprarDTO;
	}
	
}
