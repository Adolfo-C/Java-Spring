package com.curso.tdd1.controller;

import java.security.Principal;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import com.curso.tdd1.data.model.Proveedor;

@Controller
public interface IControllerTablesProveedor {
	
	public String proveedorList(
			Principal principal,
			Model model, 
			HttpServletRequest request);

	public String proveedorDelete(
			Long id, 
			Principal principal, 
			Model model, 
			HttpServletRequest request);

	public String proveedorDelete(
			Proveedor proveedor, 
			Principal principal, 
			Model model, 
			HttpServletRequest request);
	
	public void dataToMaster(
			Principal principal, 
			Model model, 
			HttpServletRequest request);
	
}
