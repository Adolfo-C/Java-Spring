package com.curso.tdd1.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.curso.tdd1.data.model.Alumno;

@Service
public interface IAlumnoService {

	public List<Alumno> findListAll(); 
	
	public Optional<Alumno> findOptionalById(Long id);

	public Optional<Alumno> findOptionalByNif(String nif);

	public Alumno save(Alumno alumno);
	
	public Boolean deleteById(Long id);
	
	public Boolean existsById(Long id); 

	public Boolean existsByNif(String nif); 

	public Alumno newEntity();
	
	public Long countByAlumnoId(Long id);
	
	public Double calculateProgressAlumno(Alumno alumno, 
			Long countCapitulo);

}
