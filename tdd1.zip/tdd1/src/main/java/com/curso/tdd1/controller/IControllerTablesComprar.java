package com.curso.tdd1.controller;

import java.security.Principal;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;

import com.curso.tdd1.data.dto.ComprarDTOForMultipleAdd;
import com.curso.tdd1.data.model.Comprar;

@Controller
public interface IControllerTablesComprar {
	
	public String comprarList(
			Principal principal,
			Model model, 
			HttpServletRequest request);

	public String comprarAdd(
			Principal principal, 
			Model model, 
			HttpServletRequest request);

	public String comprarAdd(
			@Valid Comprar comprar,
			BindingResult bindingResult,
			Principal principal, 
			Model model, 
			HttpServletRequest request);
	
	public void dataToMaster(
			Principal principal, 
			Model model, 
			HttpServletRequest request);

	public String comprarView(
			Long id, 
			Principal principal, 
			Model model, 
			HttpServletRequest request);

	public String comprarUpdate(
			Long id, 
			Principal principal, 
			Model model, 
			HttpServletRequest request);

	public String comprarUpdate(
			@Valid Comprar comprar,
			BindingResult bindingResult,
			Principal principal, 
			Model model, 
			HttpServletRequest request);
	
	public String comprarDelete(
			Long id, 
			Principal principal, 
			Model model, 
			HttpServletRequest request);

	public String comprarDelete(
			@Valid Comprar comprar,
			BindingResult bindingResult,
			Principal principal, 
			Model model, 
			HttpServletRequest request);

	public String comprarMultipleAdd(
			Principal principal, 
			Model model, 
			HttpServletRequest request);
	
	public String comprarMultipleAdd(
			@Valid ComprarDTOForMultipleAdd comprarDTO,
			BindingResult bindingResult,
			Principal principal, 
			Model model, 
			HttpServletRequest request);
}
