package com.curso.tdd1.controllerImpl;

import java.security.Principal;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.curso.tdd1.controller.IControllerTablesComprar;
import com.curso.tdd1.data.dto.ComprarDTOForMultipleAdd;
import com.curso.tdd1.data.model.Comprar;
import com.curso.tdd1.data.model.Producto;
import com.curso.tdd1.service.IClienteService;
import com.curso.tdd1.service.IComprarDTOForMultipleAddService;
import com.curso.tdd1.service.IComprarService;
import com.curso.tdd1.service.IProductoService;

import lombok.extern.slf4j.Slf4j;

@Controller
@RequestMapping("/comprar")
@Slf4j
public class TablesComprarControllerImpl implements IControllerTablesComprar {
    
    @Autowired
    private IComprarService comprarService;
    
    @Autowired
    private IComprarDTOForMultipleAddService comprarDTOForMultipleAddService;

    @Autowired
    private IProductoService productoService;
    
    @Autowired
    private IClienteService clienteService;
    
    @Autowired
    private UserDetailsService userDetailsService;
    
    @Override
	@GetMapping(value = {"/multipleAdd"})
	public String comprarMultipleAdd(
			Principal principal, 
			Model model, 
			HttpServletRequest request) {
		log.info("TRAZA: método comprarMultipleAdd-GET");
		// Primero inyectamos un nuevo DTO:
		ComprarDTOForMultipleAdd comprarDTO = comprarDTOForMultipleAddService.newDTO();
		log.info("comprarDTOForMultipleAdd.getProductoMap()-GET: " + comprarDTO.getComprarMultipleMap());
		// Inyectamos la ista completa de clientes:
		model.addAttribute("clienteList", clienteService.findAll());
		//
		// Rellenamos e Inyectamos el map completo de Producto:
	    for (Producto producto : productoService.findAll()) {
	    	comprarDTO.getComprarMultipleMap().put(producto.getDescripcion(), 0);
	    }
		model.addAttribute("comprarDTO", comprarDTO);
		log.info("comprarDTO.getComprarMultipleMap()-GET: " + comprarDTO.getComprarMultipleMap());
		//
		this.dataToMaster(principal, model, request);
		//
		return "/dialectLayouts/comprar/comprarAddMultipleCentral"; // Lo envía a la página html
	}
	
	@Override
	@PostMapping(value = {"/multipleAdd"})
	public String comprarMultipleAdd(
			@Valid ComprarDTOForMultipleAdd comprarDTO,
			BindingResult bindingResult,
			Principal principal, 
			Model model, 
			HttpServletRequest request) {
		//
		String returned = "redirect:/comprar/page"; // Para redireccionar a la lista de Comprar 
		log.info("TRAZA: método comprarMultipleAdd-POST: " + comprarDTO.getComprarMultipleMap());
		// Comprobamos si hay errores
		if (bindingResult.hasErrors()) {			
			log.warn("ERRORES DE VALIDACIÓN: " + bindingResult.getAllErrors());
			//Mantenemos al usuario en el formulario para que corrija los errores o cancele
			returned = "/dialectLayouts/comprar/comprarAddMultipleCentral"; 
		}
		else {
			// Guardamos el nuevo Comprar
			log.info("Antes de guardar el comprarDTO: " + comprarDTO);				
			//for (Producto producto : comprarDTO.getComprarMultipleMap()) log.info("\t> " + producto);
			for (String key : comprarDTO.getComprarMultipleMap().keySet()) {
				log.info("\t> " + key + " --> " + comprarDTO.getComprarMultipleMap().get(key));				
			}
			List<Comprar> comprarMultipleList = comprarDTOForMultipleAddService.saveMultiple(comprarDTO);
			log.info("Después de guardar el comprarDTO: " + comprarDTO);
			for (Comprar comprar : comprarMultipleList) log.info("\t> " + comprar);
		}
		//
		this.dataToMaster(principal, model, request);
		//
		return returned;
	}
  

	@Override
	@GetMapping(value = {"/view/{id}"})
	public String comprarView(
			@PathVariable("id") Long id,
			Principal principal, 
			Model model, 
			HttpServletRequest request) {
		log.info("TRAZA: método comprarView");
		//
		model.addAttribute("comprar", comprarService.findOptionalById(id).get());
		this.dataToMaster(principal, model, request);
		return "/dialectLayouts/comprar/comprarViewCentral";
	}
	
	@Override
	@GetMapping(value = {"/delete/{id}"})
	public String comprarDelete(
			@PathVariable("id") Long id,
			Principal principal, 
			Model model, 
			HttpServletRequest request) {
		log.info("TRAZA: método comprarDelete-GET");
		//
		model.addAttribute("comprar", comprarService.findOptionalById(id).get());
		this.dataToMaster(principal, model, request);
		return "/dialectLayouts/comprar/comprarDeleteCentral";
	}
	
	@Override
	@GetMapping(value = {"/update/{id}"})
	public String comprarUpdate(
			@PathVariable("id") Long id,
			Principal principal, 
			Model model, 
			HttpServletRequest request) {
		log.info("TRAZA: método comprarUpdate-GET");
		//
		model.addAttribute("comprar", comprarService.findOptionalById(id).get());
		model.addAttribute("productoList", productoService.findAll());
		model.addAttribute("clienteList", clienteService.findAll());
		this.dataToMaster(principal, model, request);
		return "/dialectLayouts/comprar/comprarUpdateCentral";
	}
  
	@Override
	@GetMapping(value = {"/add"})
	public String comprarAdd(Principal principal, Model model, HttpServletRequest request) {
		log.info("TRAZA: método comprarAdd-GET");
		//
		model.addAttribute("comprar", comprarService.newComprar());
		model.addAttribute("productoList", productoService.findAll());
		model.addAttribute("clienteList", clienteService.findAll());
		this.dataToMaster(principal, model, request);
		return "/dialectLayouts/comprar/comprarAddCentral";
	}
	
	@Override
	@GetMapping(value = {"/page"})
	public String comprarList(Principal principal, Model model, HttpServletRequest request) {
		log.info("TRAZA: método comprarList");
		// Primero ver si accedemos a todos los registros de la tabla Comprar:
		model.addAttribute("comprarList", comprarService.findAll());
		//
		this.dataToMaster(principal, model, request);
		return "/dialectLayouts/comprar/comprarListCentral";
	}

	@Override
	public void dataToMaster(Principal principal, Model model, HttpServletRequest request) {
		// Inyectamos el usuario en la página
		model.addAttribute("username", principal.getName());
		// Inyectar la lista de roles
		model.addAttribute("authoritySet", 
			userDetailsService
			.loadUserByUsername(principal.getName())
			.getAuthorities()
			.stream()
			.map(x -> x.toString())
			.collect(Collectors.toSet())
			);
		//		
	}

	@Override
	@PostMapping(value = {"/add"})
	public String comprarAdd(
			@Valid Comprar comprar, 
			BindingResult bindingResult, 
			Principal principal, 
			Model model,
			HttpServletRequest request) {
		String returned = "";
		log.info("TRAZA: método comprarAdd-POST");
		if (bindingResult.hasErrors()) {
			log.info("HAY ERRORES DE VALIDACIÓN: " +  bindingResult.getAllErrors());
			model.addAttribute("productoList", productoService.findAll());
			model.addAttribute("clienteList", clienteService.findAll());
			this.dataToMaster(principal, model, request);
			returned = "/dialectLayouts/comprar/comprarAddCentral";
		}
		else {
			log.info("comprar: " + comprar);
			log.info("Añadido comprar: " + comprarService.save(comprar));
			returned = "redirect:/comprar/page";			
		}
		return returned;
	}

	@Override
	@PostMapping(value = {"/update"})
	public String comprarUpdate(
			@Valid Comprar comprar, 
			BindingResult bindingResult, 
			Principal principal, 
			Model model,
			HttpServletRequest request) {
		String returned = "";
		log.info("TRAZA: método comprarUpdate-POST");
		if (bindingResult.hasErrors()) {
			log.info("HAY ERRORES DE VALIDACIÓN: " +  bindingResult.getAllErrors());
			model.addAttribute("productoList", productoService.findAll());
			model.addAttribute("clienteList", clienteService.findAll());
			this.dataToMaster(principal, model, request);
			returned = "/dialectLayouts/comprar/comprarUpdateCentral";
		}
		else {
			log.info("comprar: " + comprar);
			log.info("Modificado comprar: " + comprarService.save(comprar));
			returned = "redirect:/comprar/page";			
		}
		return returned;
	}

	@Override
	@PostMapping(value = {"/delete"})
	public String comprarDelete(
			@Valid Comprar comprar, 
			BindingResult bindingResult, 
			Principal principal, 
			Model model,
			HttpServletRequest request) {
		String returned = "";
		log.info("TRAZA: método comprarDelete-POST");
		if (bindingResult.hasErrors()) {
			log.info("HAY ERRORES DE VALIDACIÓN: " +  bindingResult.getAllErrors());
			model.addAttribute("productoList", productoService.findAll());
			model.addAttribute("clienteList", clienteService.findAll());			
			this.dataToMaster(principal, model, request);
			returned = "/dialectLayouts/comprar/comprarDeleteCentral";
		}
		else {
			log.info("comprar: " + comprar);
			log.info("Eliminado comprar: " + comprarService.deleteById(comprar.getId()));
			returned = "redirect:/comprar/page";			
		}
		return returned;
	}

}