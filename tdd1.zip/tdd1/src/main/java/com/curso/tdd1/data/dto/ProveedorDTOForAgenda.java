package com.curso.tdd1.data.dto;

import java.util.ArrayList;
import java.util.List;

import com.curso.tdd1.data.model.Proveedor;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@NoArgsConstructor
@ToString
public class ProveedorDTOForAgenda {
	
	private List<Proveedor> proveedorList = new ArrayList<>();
	
	public void add(Proveedor proveedor) {
		this.proveedorList.add(proveedor);
	}

}
