package com.curso.tdd1.controllerImpl;

import java.security.Principal;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.curso.tdd1.controller.IControllerTablesProduct;
import com.curso.tdd1.data.model.Producto;
import com.curso.tdd1.service.IProductoService;
import com.curso.tdd1.service.IProveedorService;
import lombok.extern.slf4j.Slf4j;

@Controller
@RequestMapping("/product")
@Slf4j
public class TablesProductControllerImpl implements IControllerTablesProduct {
    
    @Autowired
    private IProductoService productoService;

    @Autowired
    private IProveedorService proveedorService;
    
    @Autowired
    private UserDetailsService userDetailsService;
    
	@Override
	@GetMapping(value = {"/view/{id}"})
	public String productoView(
			@PathVariable("id") Long id,
			Principal principal, 
			Model model, 
			HttpServletRequest request) {
		log.info("TRAZA: método productoView");
		//
		model.addAttribute("producto", productoService.findOptionalById(id).get());
		this.dataToMaster(principal, model, request);
		return "/dialectLayouts/producto/productoViewCentral";
	}
	
	@Override
	@GetMapping(value = {"/delete/{id}"})
	public String productoDelete(
			@PathVariable("id") Long id,
			Principal principal, 
			Model model, 
			HttpServletRequest request) {
		log.info("TRAZA: método productoDelete-GET");
		//
		model.addAttribute("producto", productoService.findOptionalById(id).get());
		this.dataToMaster(principal, model, request);
		return "/dialectLayouts/producto/productoDeleteCentral";
	}
	
	@Override
	@GetMapping(value = {"/update/{id}"})
	public String productoUpdate(
			@PathVariable("id") Long id,
			Principal principal, 
			Model model, 
			HttpServletRequest request) {
		log.info("TRAZA: método productoUpdate-GET");
		//
		model.addAttribute("producto", productoService.findOptionalById(id).get());
		this.dataToMaster(principal, model, request);
		model.addAttribute("proveedorList", proveedorService.findAll());
		return "/dialectLayouts/producto/productoUpdateCentral";
	}
  
	@Override
	@GetMapping(value = {"/add"})
	public String productoAdd(Principal principal, Model model, HttpServletRequest request) {
		log.info("TRAZA: método productoAdd-GET");
		//
		model.addAttribute("producto", productoService.newProducto());
		this.dataToMaster(principal, model, request);
		model.addAttribute("proveedorList", proveedorService.findAll());
		return "/dialectLayouts/producto/productoAddCentral";
	}
	
	@Override
	@GetMapping(value = {"/page"})
	public String productoList(Principal principal, Model model, HttpServletRequest request) {
		log.info("TRAZA: método productoList");
		// Primero ver si accedemos a todos los registros de la tabla Producto:
		model.addAttribute("productoList", productoService.findAll());
		//
		this.dataToMaster(principal, model, request);
		return "/dialectLayouts/producto/productoListCentral";
	}

	@Override
	public void dataToMaster(Principal principal, Model model, HttpServletRequest request) {
		// Inyectamos el usuario en la página
		model.addAttribute("username", principal.getName());
		// Inyectar la lista de roles
		model.addAttribute("authoritySet", 
			userDetailsService
			.loadUserByUsername(principal.getName())
			.getAuthorities()
			.stream()
			.map(x -> x.toString())
			.collect(Collectors.toSet())
			);
		//		
	}

	@Override
	@PostMapping(value = {"/add"})
	public String productoAdd(
			@Valid Producto producto, 
			BindingResult bindingResult, 
			Principal principal, 
			Model model,
			HttpServletRequest request) {
		String returned = "";
		log.info("TRAZA: método productoAdd-POST");
		if (bindingResult.hasErrors()) {
			log.info("HAY ERRORES DE VALIDACIÓN: " +  bindingResult.getAllErrors());
			model.addAttribute("proveedorList", proveedorService.findAll());
			this.dataToMaster(principal, model, request);
			returned = "/dialectLayouts/producto/productoAddCentral";
		}
		else {
			if (productoService.existsByCodigo(producto.getCodigo())) {
				log.info("CODIGO repetido: " + producto.getCodigo());
				model.addAttribute("message", "CODIGO ya existente!");
				model.addAttribute("proveedorList", proveedorService.findAll());
				this.dataToMaster(principal, model, request);
				returned = "/dialectLayouts/producto/productoAddCentral";
			}
			else {
				/*
				// ALTERNATIVA 1: a través del campo de la FK (proveedorId)
				log.info("producto: " + producto);
				producto.setProveedor(proveedorService.findById(producto.getProveedorId()).get());
				log.info("Añadido producto: " + productoService.save(producto));
				returned = "redirect:/product/page";
				*/
				// ALTERNATIVA 2: a través del campo ManyToOne (proveedor)
				log.info("producto: " + producto);
				log.info("Añadido producto: " + productoService.save(producto));
				returned = "redirect:/product/page";			
			}
		}
		return returned;
	}

	@Override
	@PostMapping(value = {"/update"})
	public String productoUpdate(
			@Valid Producto producto, 
			BindingResult bindingResult, 
			Principal principal, 
			Model model,
			HttpServletRequest request) {
		String returned = "";
		log.info("TRAZA: método productoUpdate-POST");
		if (bindingResult.hasErrors()) {
			log.info("HAY ERRORES DE VALIDACIÓN: " +  bindingResult.getAllErrors());
			this.dataToMaster(principal, model, request);
			model.addAttribute("proveedorList", proveedorService.findAll());
			returned = "/dialectLayouts/producto/productoUpdateCentral";
		}
		else {
			if (productoService.existsByCodigo(producto.getCodigo())
					&& (producto.getId() != 
						productoService.findOptionalByCodigo(producto.getCodigo()).get().getId())) {
				log.info("CODIGO repetido: " + producto.getCodigo());
				model.addAttribute("message", "CODIGO ya existente en otro Producto!");
				model.addAttribute("proveedorList", proveedorService.findAll());
				this.dataToMaster(principal, model, request);
				returned = "/dialectLayouts/producto/productoUpdateCentral";
			}
			else {
				/*
				// ALTERNATIVA 1: a través del campo de la FK (proveedorId)
				log.info("producto: " + producto);
				producto.setProveedor(proveedorService.findById(producto.getProveedorId()).get());
				log.info("Modificado producto: " + productoService.save(producto));
				returned = "redirect:/product/page";
				*/
				// ALTERNATIVA 2: a través del campo ManyToOne (proveedor)
				log.info("producto: " + producto);
				log.info("Modificado producto: " + productoService.save(producto));
				returned = "redirect:/product/page";			
			}
		}
		return returned;
	}

	@Override
	@PostMapping(value = {"/delete"})
	public String productoDelete(
			@Valid Producto producto, 
			BindingResult bindingResult, 
			Principal principal, 
			Model model,
			HttpServletRequest request) {
		String returned = "";
		log.info("TRAZA: método productoDelete-POST");
		if (bindingResult.hasErrors()) {
			log.info("HAY ERRORES DE VALIDACIÓN: " +  bindingResult.getAllErrors());
			this.dataToMaster(principal, model, request);
			returned = "/dialectLayouts/producto/productoDeleteCentral";
		}
		else {
			log.info("producto: " + producto);
			log.info("Eliminado producto: " + productoService.deleteById(producto.getId()));
			returned = "redirect:/product/page";			
		}
		return returned;
	}

}