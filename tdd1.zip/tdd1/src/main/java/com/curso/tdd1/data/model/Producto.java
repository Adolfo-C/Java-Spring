package com.curso.tdd1.data.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.AccessLevel;

@Entity
@Table(name = "producto")
@XmlRootElement
@Getter
@Setter
@NoArgsConstructor
@ToString
public class Producto implements Serializable {

	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private static final long serialVersionUID = 1L;
	
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)    
	@Basic(optional = false)
    @Column(name = "ID", unique=true, nullable=false) 
	private Long id;
	
    @Column(name = "CODIGO")
    @Size(min=2, max=5, message="Campo Codigo debe tener entre 2 y 5 caracteres")
    //@Size(min=2, max=5, message="{html.entity.validation.dni.size}")
	private String codigo;
	
    @Column(name = "DESCRIPCION")
	private String descripcion;
	
    @Column(name = "PRECIO", columnDefinition = "decimal", precision = 7, scale = 2)
    @Min(value=0, message="Valor mínimo = 0")
    @DecimalMax(value="99999.99", message="Valor máximo = 99999.99")
	private Double precio;

    // insertable=false, updatable=false: when the responsibility of creating/updating the referenced column 
    // isn't in the current entity (Producto), but in the other entity (Proveedor). 
    @Column(name = "FK_PROVEEDOR_ID", insertable=false, updatable=false)
	private Long proveedorId;
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name="FK_PROVEEDOR_ID")
    private Proveedor proveedor;
    
    @OneToMany(mappedBy = "producto", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<Comprar> comprarSet;

}
