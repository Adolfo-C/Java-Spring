package com.curso.tdd1.controllerImpl;

import java.security.Principal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.curso.tdd1.controller.IControllerAbout;
import com.curso.tdd1.data.model.Cliente;
import com.curso.tdd1.data.model.Proveedor;
import com.curso.tdd1.data.repository.ICapituloRepository;
import com.curso.tdd1.service.IAlumnoService;
import com.curso.tdd1.service.IClienteService;
import com.curso.tdd1.service.IProveedorService;
import com.curso.tdd1.serviceImpl.AlumnoServiceImpl;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class AboutControllerImpl implements IControllerAbout {
    
    @Autowired
    private UserDetailsService userDetailsService;
    
    @Autowired
    private IClienteService clienteService;

    @Autowired
    private AlumnoServiceImpl alumnoService;
    
    @Autowired
    private IProveedorService proveedorService;
    
    @Autowired
    private ICapituloRepository capituloRepository;
    
	@Override
	@GetMapping(value = {"/about"})
	public String about(Principal principal, Model model, HttpServletRequest request) {
		log.info("TRAZA: método about");
		//
		//this.testCollections(); // En este método probamos temas relacionados con Colecciones.
		this.testAlumnoServiceImpl();
		//
		// Inyectamos datos de usuario y sus roles en la página html
		this.dataToMaster(principal, model, request);
		//
		return "/dialectLayouts/about/aboutCentral" ;
	}
	
	private void testAlumnoServiceImpl() {
		//Test progress for everyone
		Long countCapitulo = capituloRepository.count();
		log.info("Progress of everyone: ");
		alumnoService.findListAll().stream()
			.forEach(x -> log.info("\t> " + x.getNombre() + " >> "
				+ alumnoService.calculateProgressAlumno(x, countCapitulo)));
	}
	
	private void testCollections() {
		// Primero ver si accedemos a todos los registros de la tabla Cliente:
		//List<Cliente> clienteList = clienteService.findAll();
		log.info("Lista de clientes: ");
		for (Cliente cliente : clienteService.findAll()) {
			log.info("\t > " + cliente);
		}
		// Segundo ver si accedemos a un registro por su Id con un Optional:		
		Optional<Cliente> clienteOptional = clienteService.findById(5L);
		if (clienteOptional.isPresent()) {
			log.info("Cliente con id=5: " + clienteOptional.get());			
		}
		else {
			log.info("Cliente con id=5: NO EXISTE");						
		}
		// Tercero igual que el anterior pero con un operador Elvis:				
		log.info("Cliente con id=7: " + (clienteService.existsById(7L) 
				? clienteService.findById(7L).get()
				: "NO EXISTE"
					));
		//
		List<Proveedor> proveedorList = proveedorService.findAll();
		List<Proveedor> proveedorList2 = new ArrayList<Proveedor>();
		proveedorList2.addAll(proveedorList);
		proveedorList2.add(new Proveedor());
		proveedorList2.add(2, new Proveedor());
		log.info("Lista de Proveedores 2: ");
		for (Proveedor proveedor : proveedorList2) {
			log.info("\t > " + proveedor);
		}
		log.info("Proveedor de indice 3 de la lista: " + proveedorList2.get(3));
		//
		Set<String> stringSet = new HashSet<>();
		stringSet.add("String 1");
		stringSet.add("String 2");
		stringSet.add("String 3");
		log.info("Set de String: ");
		for (String string: stringSet) {
			log.info("\t > " + string);
		}
		Map<String, String> propertyMap = new HashMap<>();
		propertyMap.put("clave 1", "valor 1");
		propertyMap.put("clave 2", "valor 2");
		propertyMap.put("clave 3", "valor 3");
		log.info("propertyMap= " + propertyMap);
		//
		List<Proveedor> proveedorList3 = proveedorService.findAll();
		Consumer<Proveedor> consumer1 = p -> log.info("\t > " + p);
		Consumer<Proveedor> consumer2 = p -> log.warn("\t | " + p.getNombre());
		log.info("Stream de proveedores: ");
		proveedorList3.stream().forEach(consumer1.andThen(consumer2));
		//proveedorList3.stream().forEach(p -> log.info("\t > " + p));
		log.info("Stream de proveedores solo ANONIMO: ");
		proveedorList3.stream().filter(x -> x.getNombre().equals("ANONIMO"))
			.forEach(consumer1.andThen(consumer2));
		//
		Predicate<Proveedor> predicate1 = x -> x.getNombre().equals("ANONIMO");
		Predicate<Proveedor> predicate2 = x -> x.getId() > 5;
		log.info("Stream de proveedores solo ANONIMO e id>5 con predicate: ");
		proveedorList3.stream().filter(predicate1.and(predicate2))
			.forEach(consumer1.andThen(consumer2));	
		//
		Predicate<Proveedor> predicate3 = x -> !(x.getNombre().equals("ANONIMO"));
		Consumer<String> consumer3 = p -> log.info("\t > " + p);
		log.info("Stream de proveedores filtro NO ANONIMO y mapeado por nombre: ");
		proveedorList3.stream().filter(predicate3)
			.map(x -> x.getNombre())
			.forEach(consumer3);	
		//
		log.info("Stream de proveedores filtro NO ANONIMO, mapeado por nombre, "
				+ "devuelto en una List de String: ");
		List<String> proveedorNoAnonimoList = proveedorList3
				.stream()
				.peek(consumer1)
				.filter(predicate3)
				.peek(consumer1)
				.map(x -> x.getNombre())
				.peek(consumer3)
				.collect(Collectors.toList());
		log.info("proveedorNoAnonimoList= " + proveedorNoAnonimoList);
		//
		log.info("******* FIN testCollections() *******");
	}
	
	@Override
	public void dataToMaster(Principal principal, Model model, HttpServletRequest request) {
		// Inyectamos el usuario en la página
		model.addAttribute("username", principal.getName());
		// Inyectar la lista de roles
		model.addAttribute("authoritySet", 
			userDetailsService
			.loadUserByUsername(principal.getName())
			.getAuthorities()
			.stream()
			.map(x -> x.toString())
			.collect(Collectors.toSet())
			);
		//		
	}
	
}
