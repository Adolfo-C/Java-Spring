package com.curso.tdd1.serviceImpl;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.curso.tdd1.data.model.Cliente;
import com.curso.tdd1.data.model.Comprar;
import com.curso.tdd1.data.repository.IComprarRepository;
import com.curso.tdd1.service.IComprarService;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Service
@Getter
@Setter
@NoArgsConstructor
@ToString
public class ComprarServiceImpl implements IComprarService {

	@Autowired
	private IComprarRepository comprarRepository;
	
	@Override
	public List<Comprar> findAll() {
		return Collections.unmodifiableList(comprarRepository.findAll());
	}

	@Override
	public Optional<Comprar> findOptionalById(Long id) {
		return comprarRepository.findById(id);
	}
	
	@Override
	public Comprar save(Comprar comprar) {
		return comprarRepository.save(comprar);
	}

	@Override
	public Boolean deleteById(Long id) {
		comprarRepository.deleteById(id);		
		return !this.existsById(id);
	}
	
	@Override
	public Boolean existsById(Long id) {
		return comprarRepository.existsById(id);
	}

	@Override
	public Comprar newComprar() {
		Comprar comprar = new Comprar();
		comprar.setFecha(LocalDate.now());
		comprar.setUnidades(0);
		return comprar;
	}

	@Override
	public Comprar newComprar(LocalDate fecha, Cliente cliente) {
		Comprar comprar = new Comprar();
		comprar.setFecha(fecha);
		comprar.setCliente(cliente);
		comprar.setUnidades(0);
		comprar.setProducto(null);
		comprar.setId(null);
		return comprar;
	}
	
}
