package com.curso.tdd1.data.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.curso.tdd1.data.model.Cliente;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

@Repository
@Transactional
public interface IClienteRepository extends JpaRepository<Cliente, Long> {

	public List<Cliente> findListByNombre(String nombre);
	
	public List<Cliente> findListByNombreAndTarjetaOrderByNombreDesc(
		String nombre,
		String tarjeta);
		
	//public List<Cliente> findListByEdadBetweenAndNombreContains(
	//	int minimo, int maximo, String trozoNombre);
	
	public Optional<Cliente> findOptionalByNombreAndTarjeta(String nombre, String tarjeta);
	
	public Boolean existsByDni(String dni);

}
