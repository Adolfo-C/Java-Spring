package com.curso.tdd1.serviceImpl;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import com.curso.tdd1.data.model.Alumno;
import com.curso.tdd1.data.repository.IAlumnoRepository;
import com.curso.tdd1.data.repository.ICapituloRepository;
import com.curso.tdd1.data.repository.IEstudiarRepository;
import com.curso.tdd1.service.IAlumnoService;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Getter
@Setter
@RequiredArgsConstructor
@ToString
public class AlumnoServiceImpl2 implements IAlumnoService {

	private final Double MINIMUM_NOTA = 5.0;

	private final IAlumnoRepository alumnoRepository;
	private final IEstudiarRepository estudiarRepository;
	private final ICapituloRepository capituloRepository;
	
	/*
	// Alternativa de inyección a través del constructor
	private IAlumnoRepository alumnoRepository;
	private IEstudiarRepository estudiarRepository;
	private ICapituloRepository capituloRepository;
	
	public AlumnoServiceImpl2(
		IAlumnoRepository alumnoRepository,
		IEstudiarRepository estudiarRepository,
		ICapituloRepository capituloRepository) {
		this.alumnoRepository = alumnoRepository;
		this.estudiarRepository = estudiarRepository;
		this.capituloRepository = capituloRepository;
	}
	*/
	
	@Override
	public List<Alumno> findListAll() {
		return Collections.unmodifiableList(alumnoRepository.findAll());
	}

	@Override
	public Optional<Alumno> findOptionalById(Long id) {
		return alumnoRepository.findById(id);
	}

	@Override
	public Optional<Alumno> findOptionalByNif(String nif) {
		return alumnoRepository.findOptionalByNif(nif);
	}
	
	@Override
	public Alumno save(Alumno alumno) {
		Alumno alumnoReturned = null;
		try {
			alumnoReturned = alumnoRepository.save(alumno);
		}
		catch (DataIntegrityViolationException e) {
			log.info("Excepcion al guardar alumno: " + e.getMessage());
		}
		return alumnoReturned;
	}

	@Override
	public Boolean deleteById(Long id) {
		alumnoRepository.deleteById(id);		
		return !this.existsById(id);
	}
	
	@Override
	public Boolean existsById(Long id) {
		return alumnoRepository.existsById(id);
	}

	@Override
	public Alumno newEntity() {
		return new Alumno();
	}

	@Override
	public Boolean existsByNif(String nif) {
		return alumnoRepository.existsByNif(nif);
	}

	@Override
	public Long countByAlumnoId(Long id) {
		return (long) estudiarRepository.countByAlumnoId(id);
	}

	@Override
	public Double calculateProgressAlumno(Alumno alumno, Long countCapitulo) {
		long finishedCapitulo = alumno
				.getEstudiarSet()
				.stream()
				.filter(x -> (x.getFFin() != null) 
						&& (x.getNota() != null) 
						&& (x.getNota() >= MINIMUM_NOTA))
				.count();
		Double progress = null;
		try {
			progress = (double)(finishedCapitulo * 100) / (double)countCapitulo;
		}
		catch (ArithmeticException e) {
			log.info("Table Capitulo is EMPTY!!!");
			progress = Double.POSITIVE_INFINITY;
		}
		return progress;
	}
}
