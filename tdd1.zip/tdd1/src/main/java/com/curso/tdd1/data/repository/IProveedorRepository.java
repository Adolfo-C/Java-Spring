package com.curso.tdd1.data.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.curso.tdd1.data.model.Proveedor;
import java.util.List;

import javax.transaction.Transactional;

@Repository
@Transactional
public interface IProveedorRepository extends JpaRepository<Proveedor, Long> {

	public List<Proveedor> findListByNombre(String nombre);
	
	public List<Proveedor> findListByNombreAndDireccionOrderByNombreDesc(
		String nombre,
		String direccion);
	
}
