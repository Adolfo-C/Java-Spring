package com.curso.tdd1.serviceImpl;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.curso.tdd1.data.model.Producto;
import com.curso.tdd1.data.repository.IProductoRepository;
import com.curso.tdd1.service.IProductoService;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Service
@Getter
@Setter
@NoArgsConstructor
@ToString
public class ProductoServiceImpl implements IProductoService {

	@Autowired
	private IProductoRepository productoRepository;
	
	@Override
	public List<Producto> findAll() {
		return Collections.unmodifiableList(productoRepository.findAll());
	}

	@Override
	public Optional<Producto> findOptionalById(Long id) {
		return productoRepository.findById(id);
	}

	@Override
	public Optional<Producto> findOptionalByCodigo(String codigo) {
		return productoRepository.findOptionalByCodigo(codigo);
	}

	@Override
	public Optional<Producto> findOptionalByDescripcion(String descripcion) {
		return productoRepository.findOptionalByDescripcion(descripcion);
	}
	
	@Override
	public Producto save(Producto producto) {
		return productoRepository.save(producto);
	}

	@Override
	public Boolean deleteById(Long id) {
		productoRepository.deleteById(id);		
		return !this.existsById(id);
	}
	
	@Override
	public Boolean existsById(Long id) {
		return productoRepository.existsById(id);
	}

	@Override
	public Producto newProducto() {
		return new Producto();
	}

	@Override
	public Boolean existsByCodigo(String codigo) {
		return productoRepository.existsByCodigo(codigo);
	}
}
