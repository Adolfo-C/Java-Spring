package com.curso.tdd1.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.curso.tdd1.data.model.Producto;

@Service
public interface IProductoService {

	public List<Producto> findAll(); 
	
	public Optional<Producto> findOptionalById(Long id);

	public Optional<Producto> findOptionalByCodigo(String codigo);

	public Optional<Producto> findOptionalByDescripcion(String descripcion);

	public Producto save(Producto producto);
	
	public Boolean deleteById(Long id);
	
	public Boolean existsById(Long id); 
	
	public Producto newProducto();
	
	public Boolean existsByCodigo(String codigo);

}
