package com.curso.tdd1.controller;

import java.security.Principal;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;

import com.curso.tdd1.data.model.Cliente;

@Controller
public interface IControllerTablesCustomer {
	
	public String clienteList(
			Principal principal,
			Model model, 
			HttpServletRequest request);

	public String clienteAdd(
			Principal principal, 
			Model model, 
			HttpServletRequest request);

	public String clienteAdd(
			@Valid Cliente cliente,
			BindingResult bindingResult,
			Principal principal, 
			Model model, 
			HttpServletRequest request);
	
	public void dataToMaster(
			Principal principal, 
			Model model, 
			HttpServletRequest request);

	public String clienteView(
			Long id, 
			Principal principal, 
			Model model, 
			HttpServletRequest request);

}
