package com.curso.tdd1.config;

import java.util.Locale;

import javax.sql.DataSource;

import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.i18n.LocaleChangeInterceptor;
import org.springframework.web.servlet.i18n.SessionLocaleResolver;
import org.springframework.web.servlet.view.InternalResourceViewResolver;
import org.thymeleaf.spring5.SpringTemplateEngine;

import nz.net.ultraq.thymeleaf.layoutdialect.LayoutDialect;

@Configuration
@EnableAspectJAutoProxy(proxyTargetClass=true)
public class I18nConfiguration implements WebMvcConfigurer {

	// Este método es necesario para disponer del dialect de Thymeleaf que permite
	// construir layouts y templates reutilizables:
    public InternalResourceViewResolver getInternalResourceViewResolver() {
        InternalResourceViewResolver resolver = new InternalResourceViewResolver();
        //resolver.setPrefix("templates/*");   // Alternativa en application.properties
        //resolver.setSuffix(".html");		// Alternativa en application.properties	
        SpringTemplateEngine engine = new SpringTemplateEngine();
        engine.addDialect(new LayoutDialect());
        return resolver;
    }	

	// Este bean es necesario para el cambio de language:
	@Bean
	public LocaleResolver localeResolver() {
	    SessionLocaleResolver localeResolver = new SessionLocaleResolver();
	    localeResolver.setDefaultLocale(new Locale("es", "ES"));
	    //Alternativa:
	    //localeResolver.setDefaultLocale(Locale.getDefault());
	    //
	    return localeResolver;
	  }

	// Este bean es necesario para usar los message_xx.properties:
	@Bean
	public ResourceBundleMessageSource messageSource() {
		ResourceBundleMessageSource rbms=new ResourceBundleMessageSource();
		rbms.setBasename("i18n/message");
		rbms.setDefaultEncoding("UTF-8");
		return rbms;
	}

	// Este bean es necesario para usar i18n con el parametro 'language':
	@Bean
	public LocaleChangeInterceptor localeChangeInterceptor() {
	    LocaleChangeInterceptor localeInterceptor = new LocaleChangeInterceptor();
	    localeInterceptor.setIgnoreInvalidLocale(true);
	    localeInterceptor.setParamName("language");
	    return localeInterceptor;
	}
	
	// Este metodo es necesario para agregar el interceptor del 'language':	
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
	    registry.addInterceptor(new Interceptors());
	    registry.addInterceptor(localeChangeInterceptor());
	}
	
}
