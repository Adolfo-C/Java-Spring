package com.curso.tdd1.data.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.curso.tdd1.data.model.Alumno;
import java.util.Optional;

import javax.transaction.Transactional;

@Repository
@Transactional
public interface IAlumnoRepository extends JpaRepository<Alumno, Long> {
	
	public Optional<Alumno> findOptionalByNif(String nif);

	public Boolean existsByNif(String nif);
	
}
