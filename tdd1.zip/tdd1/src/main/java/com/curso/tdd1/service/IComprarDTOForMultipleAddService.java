package com.curso.tdd1.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.curso.tdd1.data.model.Comprar;
import com.curso.tdd1.data.dto.ComprarDTOForMultipleAdd;

@Service
public interface IComprarDTOForMultipleAddService {

	public ComprarDTOForMultipleAdd newDTO();

	public List<Comprar> saveMultiple(ComprarDTOForMultipleAdd comprarMultipleDTO);
		
}
