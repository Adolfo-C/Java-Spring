package com.curso.tdd1.data.model;

import java.io.Serializable;
import java.time.LocalDate;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;

@Entity
@Table(name = "estudiar")
@XmlRootElement
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Estudiar implements Serializable {

	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private static final long serialVersionUID = 1L;
	
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)    
	@Basic(optional = false)
    @Column(name = "ID", unique=true, nullable=false) 
	private Long id;

    @Column(name = "FINICIO", nullable=false)
    @DateTimeFormat(pattern = "yyyy-MM-dd") // Formato ISO
	private LocalDate fInicio; //LocalTime, LocalDateTime

    @Column(name = "FFIN")
    @DateTimeFormat(pattern = "yyyy-MM-dd") // Formato ISO
	private LocalDate fFin; //LocalTime, LocalDateTime   

    @Column(name = "NOTA", columnDefinition = "decimal", precision = 4, scale = 2)
    @Min(value = 0, message = "Valor mínimo = 0")
    @DecimalMax(value = "10.00", message = "Valor máximo = 10.00")
	private Double nota;
	
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name="FK_ALUMNO_ID", nullable=false)
    @ToString.Exclude
    private Alumno alumno;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name="FK_CAPITULO_ID", nullable=false)
    @ToString.Exclude
    private Capitulo capitulo;
}
