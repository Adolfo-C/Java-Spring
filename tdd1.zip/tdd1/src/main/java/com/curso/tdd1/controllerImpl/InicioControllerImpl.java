package com.curso.tdd1.controllerImpl;

import java.security.Principal;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.curso.tdd1.controller.IControllerInicio;
import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class InicioControllerImpl implements IControllerInicio {
    
    @Autowired
    private UserDetailsService userDetailsService;
    
	@Override
	@GetMapping(value = {"/inicioLogado"})
	public String inicio(Principal principal, Model model, HttpServletRequest request) {
		log.info("TRAZA: método inicio");
		// Inyectamos datos de usuario y sus roles en la página html
		this.dataToMaster(principal, model, request);
		//
		return "/dialectLayouts/central" ;
	}
	
	@Override
	public void dataToMaster(Principal principal, Model model, HttpServletRequest request) {
		// Inyectamos el usuario en la página
		model.addAttribute("username", principal.getName());
		// Inyectar la lista de roles
		model.addAttribute("authoritySet", 
			userDetailsService
			.loadUserByUsername(principal.getName())
			.getAuthorities()
			.stream()
			.map(x -> x.toString())
			.collect(Collectors.toSet())
			);
		//		
	}

}
