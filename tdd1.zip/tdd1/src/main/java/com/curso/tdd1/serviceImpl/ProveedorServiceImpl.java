package com.curso.tdd1.serviceImpl;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.curso.tdd1.data.model.Proveedor;
import com.curso.tdd1.data.repository.IProveedorRepository;
import com.curso.tdd1.service.IProveedorService;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Service
@Getter
@Setter
@NoArgsConstructor
@ToString
public class ProveedorServiceImpl implements IProveedorService {

	@Autowired
	private IProveedorRepository proveedorRepository;
	
	@Override
	public List<Proveedor> findAll() {
		return Collections.unmodifiableList(proveedorRepository.findAll());
	}

	@Override
	public Optional<Proveedor> findById(Long id) {
		return proveedorRepository.findById(id);
	}

	@Override
	public Proveedor save(Proveedor proveedor) {
		return proveedorRepository.save(proveedor);
	}

	@Override
	public Boolean deleteById(Long id) {
		proveedorRepository.deleteById(id);		
		return !this.existsById(id);
	}
	
	@Override
	public Boolean existsById(Long id) {
		return proveedorRepository.existsById(id);
	}


}
