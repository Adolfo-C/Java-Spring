package com.curso.tdd1.controllerImpl;

import java.security.Principal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.curso.tdd1.controller.IControllerContacts;
import com.curso.tdd1.data.model.Cliente;
import com.curso.tdd1.data.model.Proveedor;
import com.curso.tdd1.data.repository.ICapituloRepository;
import com.curso.tdd1.service.IAlumnoService;
import com.curso.tdd1.service.IClienteService;
import com.curso.tdd1.service.IProveedorService;
import com.curso.tdd1.serviceImpl.AlumnoServiceImpl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
@RequiredArgsConstructor
public class ContactsControllerImpl implements IControllerContacts {
    
    private final UserDetailsService userDetailsService;
       
	@Override
	@GetMapping(value = {"/contacts"})
	public String contacts(Principal principal, Model model, HttpServletRequest request) {
		log.info("TRAZA: método contacts > username= " + principal.getName()
			+ " >> authorities= " + userDetailsService
			.loadUserByUsername(principal.getName()).getAuthorities().toString());
		//
		// Inyectamos username y authorities en el html
		model.addAttribute("username", principal.getName());
		model.addAttribute("authoritiesString", userDetailsService
				.loadUserByUsername(principal.getName()).getAuthorities().toString());
		//
		return "/contacts" ;
	}
	
}
