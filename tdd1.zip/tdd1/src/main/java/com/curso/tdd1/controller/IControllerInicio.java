package com.curso.tdd1.controller;

import java.security.Principal;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

@Controller
public interface IControllerInicio {
	
	public String inicio(
			Principal principal,
			Model model, 
			HttpServletRequest request);

	void dataToMaster(
			Principal principal, 
			Model model, 
			HttpServletRequest request);

}
