package com.curso.tdd1.data.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.AccessLevel;

@Entity
@Table(name = "cliente")
@XmlRootElement
@Getter
@Setter
@NoArgsConstructor
@ToString
public class Cliente implements Serializable {

	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private static final long serialVersionUID = 1L;
	
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)    
	@Basic(optional = false)
    @Column(name = "ID", unique=true, nullable=false) 
	private Long id;
	
    @Column(name = "DNI")
    @Size(min=2, max=9, message="Campo Dni debe tener entre 2 y 9 caracteres")
    //@Size(min=2, max=9, message="{html.entity.validation.dni.size}")
	private String dni;
	
    @Column(name = "NOMBRE")
	private String nombre;
	
    @Column(name = "TARJETA")
    @Size(min=16, max=16, message="Campo Tarjeta debe tener 16 caracteres")
	private String tarjeta;

    @OneToMany(mappedBy = "cliente", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<Comprar> comprarSet;
}
