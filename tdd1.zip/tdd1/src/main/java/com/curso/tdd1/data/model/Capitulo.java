package com.curso.tdd1.data.model;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;

@Entity
@Table(name = "capitulo")
@XmlRootElement
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Capitulo implements Serializable {

	@Getter(AccessLevel.NONE)
	@Setter(AccessLevel.NONE)
	private static final long serialVersionUID = 1L;
	
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)    
	@Basic(optional = false)
    @Column(name = "ID", unique=true, nullable=false) 
	private Long id;
	
    @Column(name = "ORDEN", unique=true, nullable=false)
    @Min(value=0, message="Valor minimo = 0")
    @Max(value=99, message="Valor máximo = 99")
	private Integer orden;
	
    @Column(name = "TITULO", nullable=false)
    @Size(min=1, max=200, message="Campo Titulo debe tener entre 1 y 200 caracteres")
	private String titulo;

    @OneToMany(fetch = FetchType.EAGER, mappedBy = "capitulo", cascade = CascadeType.ALL, orphanRemoval = true)
    private Set<Estudiar> estudiarSet;
}
